package oopEvent;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

//Abstraction
abstract class Absemployee {
    abstract void work();
    void testing() {
    	System.out.println("Object Oriented Programming is cool");
	}
}

class Employee extends Absemployee{
    protected String Name;
    protected int ID;
    protected String Job, Task;

    public void setTask(String task){
        Task = task;
    }
    public String getTask(){
        return Task;
    }
    public String getName(){
        return Name;
    }
    
    public int getID() {
    	return ID;
    }

    public Employee(int id, String name, String job){
    	ID = id;
    	Name = name;
        Job = job;
    }

    void display(){
    	System.out.println("Employee ID : " + ID);
        System.out.println("Employee Name : " + Name);
        System.out.println("Employee Job : " + Job);
    }

    public void work(){
        System.out.println("Preparing work");
    }

    public String toString(){
        return ID +"\t"+ Name + "\t" + Job + "\tN/A";
    }
    
}

class Programmer extends Employee{
    String Language;
    public Programmer (int id, String name,String job, String language){
        super(id, name, job);
        Language = language;
    }

    public void work(){
        System.out.println("The programmer is working on " + Language + " language");
    }
    public String toString(){
        return ID +"\t"+ Name+ "\t" + Job + "\t" + Language;
    }
}

class Teacher extends Employee{

    String Subject;
    public Teacher(int id, String name, String job, String subject) {
    	super(id, name, job);
        Subject = subject;
    }
    public void work(){
        System.out.println("The Teacher is teaching " + Subject + " subject");
    }

    public String toString() {
        return ID +"\t"+ Name+ "\t" + Job + "\t" + Subject;
    }
}

public class introduction{
	private static Scanner scan = new Scanner(System.in);
	//list of all the employee
	static ArrayList<Employee> empList = new ArrayList<>();
	//validation for checking if there is a number in a string
	static boolean chkstr(String str) {
		for (int i = 0; i < str.length(); i++) {
            if (Character.isDigit(str.charAt(i))){
                return false;
            }
		}
        return true;
	}
	
	static int index = 0;
	//search the ID of the employee
	static public int searchID() {
    	System.out.print("Type the ID of the employee : ");
    	int employeeID = scan.nextInt();
    	scan.nextLine();
    	for(int k=0 ; k <= (empList.size()-1); k++){
    		if(empList.get(k).getID() == employeeID){
    			index = k;
            }                
        }
    	return index;
    }
	
    public static void main(String[] args){
    	
        int choose;
        //auto generate employee ID
        int empID = 100;
        //give the current index of the employee
        int idState = 0;
        //array to store the operations and jobs 
        String[] operations = {"1. Add Employee","2. Set task","3. See task",
							"4. Display Information","5. See work", "6. Remove Employee","7. Display all employee","8. Exit Programme"};
        String[] addType = {"1. General Employee","2. Programmer","3. Teacher"};
        
        while(true){
        	System.out.println("Welcome to our Employee Management System");
        	System.out.println("*****************************************");
        	//for-each loop
            for(String j:operations) {
            	System.out.println(j);
            }
            System.out.println("*****************************************");
            System.out.print("Type what operation that you want to do : ");
            choose = scan.nextInt();
            scan.nextLine();
            //validation input for number of operations
            while(choose < 1 || choose > 8){
	            	System.out.print("Enter a number between 1-8 : ");
	            	choose = scan.nextInt();
	            	scan.nextLine();
            }
            //Adding employee to the ArrayList empList
			if(choose == 1){ 
            	for(String j:addType) {
                	System.out.println(j);
                }
            	System.out.print("Type what employee do you want to add : ");
            	int empType = scan.nextInt();
            	scan.nextLine();
            	//validation input for number of jobs
            	while(empType < 1 || empType > 3){
	            	System.out.print("Enter a number between 1-3 : ");
	            	empType = scan.nextInt();
	            	scan.nextLine();
            	}
            	
                System.out.println("Type your employee details here");
                System.out.println("*******************************");
                System.out.print("Name : ");
                String empName = scan.nextLine();
                while(chkstr(empName) == false) {
                	System.out.print("Type in a string : ");
                	empName = scan.nextLine();
                }
                
                System.out.print("Job : ");
                String empJob = scan.nextLine();
                while(chkstr(empJob) == false) {
                	System.out.print("Type in a string : ");
                	empJob = scan.nextLine();
                }
                //Choose which role for the employee
                if(empType == 1){
                    empList.add(new Employee(empID,empName,empJob));
                    System.out.println();
                }
                else if(empType == 2){
                    System.out.print("Programming Language : ");
                    String empLang = scan.nextLine();
                    while(chkstr(empLang) == false) {
                    	System.out.print("Type in a string : ");
                    	empLang = scan.nextLine();
                    }
                    empList.add(new Programmer(empID,empName,empJob,empLang));
                    System.out.println();
                }
                else if(empType == 3){
                    System.out.print("Subject : ");
                    String empSub = scan.nextLine();
                    while(chkstr(empSub) == false) {
                    	System.out.print("Type in a string : ");
                    	empSub = scan.nextLine();
                    }
                    empList.add(new Teacher(empID,empName,empJob,empSub));
                    System.out.println();
                }
                System.out.println(empList.get(idState).getName() + " with ID of " + empID +" has been successfully added yayy!!\n");
            }
			//Setting the task for the employee
            else if (choose == 2) {
            	searchID();
            	System.out.print("Type the task for the employee : ");
            	String emptask = scan.nextLine();            	
            	empList.get(index).setTask(emptask);
            	System.out.println("Task for the employee has been successfully set\n");
            	}
			//Seeing the task that has been set previously
            else if (choose == 3) {
            	searchID();
            	
            	System.out.print(empList.get(index).getName() + " has this task : ");
            	System.out.println(empList.get(index).getTask());
            	System.out.println();
            }
			//Displaying the information of the employee
            else if(choose ==  4) {
            	searchID();
            	empList.get(index).display();
            	System.out.println();
            }
			//using the work() method for showing polymorphism
            else if (choose == 5) {
            	searchID();
            	
            	empList.get(index).work();
            	System.out.println();
            }
			//Removing the employee from the ArrayList
            else if(choose == 6) {
            	searchID();
            	System.out.println(empList.get(index).getName() + " has been succesfully removed from the system");
            	empList.remove(index);
            	System.out.println();
            }
			//Printing the employees using Iterator
            else if(choose == 7) {
            	Iterator<Employee> it = empList.iterator();
            	System.out.println("The Employees are :");
            	System.out.println("ID\tName\t\tJob\t\tSubject/Programming Language");
    	        while(it.hasNext()) {
    	            System.out.println(it.next());
    	        }
    	        System.out.println();
            }
			//Terminate the program
            else if(choose == 8){
            	System.out.println("Thank you for using our system have a great day!");
                break;
            }
			
			empID++;
			idState++;
        }
    }
}